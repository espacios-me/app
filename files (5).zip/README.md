# espacios.me — Cloudflare Worker

Static site served via Cloudflare Workers + Static Assets.

## Structure

```
espacios-worker/
├── src/
│   └── index.ts          ← Worker routing logic
├── public/               ← All HTML files go here
│   ├── espacios-main.html
│   ├── atom-landing.html
│   ├── espacios-privacy.html
│   ├── espacios-terms.html
│   ├── atom-privacy.html
│   └── atom-terms.html
├── wrangler.jsonc
├── package.json
└── tsconfig.json
```

## URL routing

| URL                  | File                    |
|----------------------|-------------------------|
| espacios.me/         | espacios-main.html      |
| espacios.me/atom     | atom-landing.html       |
| espacios.me/privacy  | espacios-privacy.html   |
| espacios.me/terms    | espacios-terms.html     |
| espacios.me/atom/privacy | atom-privacy.html   |
| espacios.me/atom/terms   | atom-terms.html     |

## Deploy

### One-time setup
```bash
npm install
```

### Deploy to Cloudflare
```bash
npm run deploy
```

### Local dev
```bash
npm run dev
```

## GitHub Actions (auto-deploy)

Add this secret to your GitHub repo:
- `CLOUDFLARE_API_TOKEN` — create at https://dash.cloudflare.com/profile/api-tokens
  - Use the "Edit Cloudflare Workers" template
  - Or grant: Workers Scripts:Edit, Workers Routes:Edit, Workers Deployments:Read

Every push to `main` will auto-deploy.
