// espacios.me — Cloudflare Worker
// Serves all static HTML pages with proper routing

interface Env {
  ASSETS: Fetcher;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    // Route /atom → atom-landing.html
    if (path === "/atom" || path === "/atom/") {
      url.pathname = "/atom-landing.html";
      return env.ASSETS.fetch(new Request(url.toString(), request));
    }

    // Route /privacy → espacios-privacy.html
    if (path === "/privacy" || path === "/privacy/") {
      url.pathname = "/espacios-privacy.html";
      return env.ASSETS.fetch(new Request(url.toString(), request));
    }

    // Route /terms → espacios-terms.html
    if (path === "/terms" || path === "/terms/") {
      url.pathname = "/espacios-terms.html";
      return env.ASSETS.fetch(new Request(url.toString(), request));
    }

    // Route /atom/privacy → atom-privacy.html
    if (path === "/atom/privacy" || path === "/atom/privacy/") {
      url.pathname = "/atom-privacy.html";
      return env.ASSETS.fetch(new Request(url.toString(), request));
    }

    // Route /atom/terms → atom-terms.html
    if (path === "/atom/terms" || path === "/atom/terms/") {
      url.pathname = "/atom-terms.html";
      return env.ASSETS.fetch(new Request(url.toString(), request));
    }

    // Root → espacios-main.html
    if (path === "/" || path === "") {
      url.pathname = "/espacios-main.html";
      return env.ASSETS.fetch(new Request(url.toString(), request));
    }

    // All other paths — try assets directly (e.g. /espacios-main.html)
    return env.ASSETS.fetch(request);
  },
} satisfies ExportedHandler<Env>;
